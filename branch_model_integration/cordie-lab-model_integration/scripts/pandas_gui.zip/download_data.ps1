python activate cordie_venv
python .\download_data.py