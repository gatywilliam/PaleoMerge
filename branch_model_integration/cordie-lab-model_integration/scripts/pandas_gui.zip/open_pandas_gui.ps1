python activate cordie_venv
python .\open_pandas_gui.py