# installs the necessary modules for the script to run
python -m venv cordie_venv
python activate cordie_venv
pip install pandas
pip install requests
pip install openpyxl
pip install pandasgui
